% use netlab

mix = gmm(2, 2, 'full');

mix.priors = [0.5 0.5];
mix.centres = [4 2; 1 3];
mix.covars(:,:,1) = [0.625 -0.2165; -0.2165 0.875];
mix.covars(:,:,2) = [0.2241 -0.1368; -0.1368 0.9759];

[data, label] = gmmsamp(mix, 200);

figure;
hold on
plot(data(label==1, 1), data(label==1, 2), 'ro')
plot(data(label==2, 1), data(label==2, 2), 'bo')

m1 = mean(data(label==1, :));
m2 = mean(data(label==2, :));

Sw = 0;
vec = data(label==1, :) - repmat(m1, sum(label==1), 1);
for n = 1 : sum(label==1)
    Sw = Sw + vec(n, :)' * vec(n, :);
end
vec = data(label==2, :) - repmat(m2, sum(label==2), 1);
for n = 1 : sum(label==2)
    Sw = Sw + vec(n, :)' * vec(n, :);
end

w = inv(Sw)*(m2-m1)';
w = w/sqrt(w'*w)

ezplot([num2str(w(1)) '*y + ' num2str(w(2)) '*x = 0'])
