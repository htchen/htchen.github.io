%% Use Netlab

mix = gmm(1, 2, 'full');

mix.priors = [0.5 0.5];
mix.centres = [0.25; 0.8];
mix.covars(:,:,1) = [0.025];
mix.covars(:,:,2) = [0.015];

[data, label] = gmmsamp(mix, 50);

%% K Nearest Neighbors

K = 10;
x = [1/200: 1/100: 1];
N = numel(data);

p = zeros(size(x));
for i = 1 : length(x)
    [dummy, nns] = sort((repmat(x(i), N, 1)-data).^2);
    V = 2*sqrt((x(i)-data(nns(K))).^2);
    p(i) = (K/(V*N));
end

plot(x, p)
axis([0 1 0 5])