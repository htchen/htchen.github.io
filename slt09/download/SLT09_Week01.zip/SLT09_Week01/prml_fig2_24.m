%% Use Netlab

mix = gmm(1, 2, 'full');

mix.priors = [0.5 0.5];
mix.centres = [0.25; 0.8];
mix.covars(:,:,1) = [0.025];
mix.covars(:,:,2) = [0.015];

[data, label] = gmmsamp(mix, 50);

Delta = 0.04;
[hx, x] = hist(data, 1/Delta);
bar(x, hx/(Delta*numel(data)))
axis([0 1 0 5])