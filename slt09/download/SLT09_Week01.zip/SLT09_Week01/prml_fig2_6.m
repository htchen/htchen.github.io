
x = rand(10, 10000);
hx = hist(mean(x), 20);
bar(20*hx/10000)

