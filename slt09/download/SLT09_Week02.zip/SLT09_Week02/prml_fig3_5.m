N = 25;
M = 25;
L = 100;
beta = 1/((1/M)^2);
means = [0.5/(M-1) : 1/(M-1) : 1];
lambda = exp(2.6);

xx = [0:0.005:1]';
yyy = 0;
figure; 
hold on
for i = 1 : L
    x = rand(N,1);
    h = sin(2*pi*x);
    Phi = exp(-0.5*beta*(repmat(x, 1, M-1) - repmat(means, N, 1)).^2);
    Phi = [ones(size(Phi, 1), 1), Phi];
    w = inv(lambda*eye(M)+Phi'*Phi) * Phi' * h;
    
    yy = exp(-0.5*beta*(repmat(xx, 1, M-1) - repmat(means, length(xx), 1)).^2);
    yy = [ones(size(yy, 1), 1), yy]; 
    yy = yy*w;
    plot(xx, yy, 'color', rand(1,3))
    yyy = yyy + yy;
end

figure;
plot(xx, yyy/L)


