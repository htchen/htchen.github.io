a0 = -0.3;
a1 = 0.5;
N = 50;
beta = (1/0.2)^2;
alpha = 2.0;

m0 = [0; 0];
s0 = (1/alpha)*eye(2);
GD = 300;
for i = 1 : N    
    [w00, w11] = meshgrid([-1:2/GD:1], [-1:2/GD:1]);
    is0 = inv(s0);
    I = (1/(2*pi))*(1/sqrt(det(s0)))*exp(-0.5*(is0(1,1)*(m0(1)-w00).^2 + is0(2,2)*(m0(2)-w11).^2 + 2*is0(1,2)*(m0(1)-w00).*(m0(2)-w11)));
    imshow(I, [])
    set(gca, 'YDir', 'normal')
    set(gca, 'XTick', [2/GD GD/2 GD])
    set(gca, 'XTickLabel', [-1 0 1])
    set(gca, 'YTick', [2/GD GD/2 GD])
    set(gca, 'YTicklabel', [-1 0 1])
    set(gca, 'Visible', 'on')
    colormap('jet');
    
    hold on
    plot(GD*(a0+1)/2, GD*(a1+1)/2, 'w+', 'MarkerSize', 12, 'Linewidth', 2);
    hold off
    drawnow
    
    x = rand*2-1;
    t = a1*x + a0 + randn/sqrt(beta);
    
    sn = inv(inv(s0) + beta*[1; x]*[1, x]);
    mn = sn*(inv(s0)*m0 + beta*[1; x]*t);
    
    s0 = sn;
    m0 = mn;
    
end