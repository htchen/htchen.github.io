
M = 25;

beta = 1/((2/M)^2);
means = [0.5/(M-1) : 1/(M-1) : 1];

m0 = zeros(M,1);
s0 = (1/2)*eye(M);

xx = [0:0.005:1]';

figure; 
hold on

for N = 5 : 25
    
    x = rand(N,1);
    h = sin(2*pi*x) + randn(N,1)*0.1;

    
    Phi = exp(-0.5*beta*(repmat(x, 1, M-1) - repmat(means, N, 1)).^2);
    Phi = [ones(size(Phi, 1), 1), Phi];
    
       
    sn = inv(inv(s0) + beta*Phi'*Phi);
    mn = sn*(inv(s0)*m0 + beta*Phi'*h);
    
    
    phix = exp(-0.5*beta*(repmat(xx, 1, M-1) - repmat(means, length(xx), 1)).^2);
    phix = [ones(size(phix, 1), 1), phix]; 
    varyy = 1/beta + diag(phix*sn*phix');
    yy = phix*mn;    
    plot(xx, yy, 'color', rand(1,3))
    plot(xx, yy+sqrt(varyy), 'color', [0.2,0.2,0.2])
    plot(xx, yy-sqrt(varyy), 'color', [0.2,0.2,0.2])
    plot(x', h', 'bo')
    pause
end




