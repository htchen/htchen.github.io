
Run 'demo1.m' to test the histogram-based interest point detectors ('hist_corner.m').

The test images and 'display_features.m' are downloaded from 
http://www.robots.ox.ac.uk/~vgg/research/affine/

