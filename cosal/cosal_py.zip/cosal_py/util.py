import numpy as np
import cv2

def im2Vector(myImg, bSize=8):
    imgH, imgW, imgDim = myImg.shape
    mapW = imgW - bSize + 1
    mapH = imgH - bSize + 1

    shp = bSize, bSize, imgDim
    
    out_view = np.lib.stride_tricks.sliding_window_view(myImg, window_shape=shp)
    return out_view.reshape(mapH*mapW, -1, order='F').T

def vector2Im(eVector, imgH, imgW, bSize=8):

    mapW = imgW - bSize + 1
    mapH = imgH - bSize + 1

    eVector = eVector.reshape(mapH, mapW, order='F')

    mySMap = np.zeros((imgH, imgW))
    mySMap[bSize//2:mapH+bSize//2, bSize//2:mapW+bSize//2] = eVector

    kernel = np.ones((bSize, bSize))

    mySMap = cv2.filter2D(mySMap, -1, kernel)
    mySMap = mySMap * mySMap;
    mySMap = (mySMap-np.min(mySMap))/(np.max(mySMap)-np.min(mySMap))
    mySMap = np.expand_dims(mySMap, axis=2)
    return mySMap