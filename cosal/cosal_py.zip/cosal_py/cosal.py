import numpy as np
from util import im2Vector

def computeE(I1, I2, W, SMap1, SMap2):

    V1 = im2Vector(I1)
    WV1 = W @ V1

    V2 = im2Vector(I2)
    WV2 = W @ V2

    WV1 = np.abs(WV1) * im2Vector(np.tile(SMap1, (1, 1, 3)))
    pdf1 = np.sum(WV1, axis=1)
    WV2 = np.abs(WV2) * im2Vector(np.tile(SMap2, (1, 1, 3)))
    pdf2 = np.sum(WV2, axis=1)

    IKL1 = calcIKL(pdf1, pdf2)
    IKL2 = calcIKL(pdf2, pdf1)

    IKL1 = np.expand_dims(IKL1, axis=1)
    IKL2 = np.expand_dims(IKL2, axis=1)
    
    IKL1 = np.tile(IKL1, (1, WV1.shape[1]))
    EMap1 = IKL1 * WV1
    E1 = np.sum(EMap1, axis=0)

    IKL2 = np.tile(IKL2, (1, WV2.shape[1]))
    EMap2 = IKL2 * WV2
    E2 = np.sum(EMap2, axis=0)

    E1 = np.expand_dims(E1, axis=1)
    E2 = np.expand_dims(E2, axis=1)
    
    return E1, E2

def calcIKL(pdf1, pdf2):
    idx = (pdf1 > 0) | (pdf2 > 0)
    pdf1 = pdf1[idx]
    pdf2 = pdf2[idx]

    pdf1 = pdf1 / np.sum(pdf1, axis=0)
    pdf2 = pdf2 / np.sum(pdf2, axis=0)

    myeps = 1e-5

    baseKL = np.sum(pdf1 * np.log2(pdf1+myeps) - pdf1 * np.log2(pdf2+myeps), axis=0)
    deltaKL = - baseKL + np.log2(pdf1+myeps) + pdf1 + pdf1*np.log2(pdf1+myeps) \
      - np.log2(pdf2+myeps) - pdf1*np.log2(pdf2+myeps)
    deltaKL[deltaKL>0] = 0
    deltaKL = np.abs(deltaKL)
    deltaKL = deltaKL / np.sum(deltaKL, axis=0)

    IKL = np.zeros_like(pdf1).astype(np.double)
    IKL[idx] = deltaKL
    
    return IKL