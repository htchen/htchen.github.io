import numpy as np
import cv2
import matplotlib.pyplot as plt
from util import vector2Im
from cosal import computeE

W = np.load('AW.npy')

imgW, imgH = 64, 48

inImg1_ori = cv2.cvtColor(cv2.imread('p5.jpg'),cv2.COLOR_BGR2RGB)
inImg1 = cv2.resize(inImg1_ori, (imgW, imgH)).astype(np.double)/255
inImg2_ori = cv2.cvtColor(cv2.imread('p10.jpg'),cv2.COLOR_BGR2RGB)
inImg2 = cv2.resize(inImg2_ori, (imgW, imgH)).astype(np.double)/255

SMap1 = np.ones((imgH, imgW, 1)).astype(np.double)
SMap2 = np.ones((imgH, imgW, 1)).astype(np.double)

for t in range(5):
  SMap1[SMap1>0.15] = 1
  SMap2[SMap2>0.15] = 1
  inImgg1 = inImg1 * np.tile(SMap1, (1, 1, 3))
  inImgg2 = inImg2 * np.tile(SMap2, (1, 1, 3))
  E1, E2 = computeE(inImgg1, inImgg2, W, SMap1, SMap2)
  SMap1 = vector2Im(E1, imgH, imgW)
  SMap2 = vector2Im(E2, imgH, imgW)
 

SMap1 = SMap1 * SMap1
SMap1 = (SMap1-np.min(SMap1))/(np.max(SMap1)-np.min(SMap1))
SMap1 = cv2.GaussianBlur(SMap1, (9,9), 9)


SMap2 = SMap2 * SMap2
SMap2 = (SMap2-np.min(SMap2))/(np.max(SMap2)-np.min(SMap2))
SMap2 = cv2.GaussianBlur(SMap2, (9,9), 9)

f, ((ax1, ax2), (ax3, ax4)) = plt.subplots(nrows=2, ncols=2, figsize=(14, 14))
ax1.imshow(SMap1)
ax2.imshow(inImg1_ori)
ax3.imshow(SMap2)
ax4.imshow(inImg2_ori)